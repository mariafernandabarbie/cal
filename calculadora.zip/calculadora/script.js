function calcularEnderecoIP() {
    var enderecoIP = document.getElementById("enderecoIP").value;

    var octetos = enderecoIP.split(".");

    var classe = determinarClasseIP(octetos[0]);

    var mascara = determinarMascaraIP(classe);

    var enderecoRede = calcularEnderecoRede(octetos, mascara);
 
    var broadcast = calcularBroadcast(octetos, mascara);

    document.getElementById("classe").innerHTML = classe;
    document.getElementById("mascara").innerHTML = mascara;
    document.getElementById("enderecoRede").innerHTML = enderecoRede;
    document.getElementById("broadcast").innerHTML = broadcast;
  }
  
  function determinarClasseIP(primeiroOcteto) {
    primeiroOcteto = parseInt(primeiroOcteto);
  
    if (primeiroOcteto >= 1 && primeiroOcteto <= 126) {
      return "Classe A";
    } else if (primeiroOcteto >= 128 && primeiroOcteto <= 191) {
      return "Classe B";
    } else if (primeiroOcteto >= 192 && primeiroOcteto <= 223) {
      return "Classe C";
    } else if (primeiroOcteto >= 224 && primeiroOcteto <= 239) {
      return "Classe D (Multicast)";
    } else if (primeiroOcteto >= 240 && primeiroOcteto <= 255) {
      return "Classe E (Reservada)";
    } else if (primeiroOcteto == 127) {
      return "Endereço de host";
    } else {
      return "Endereço IP inválido";
    }
  }
  
  function determinarMascaraIP(classe) {
    if (classe === "Classe A") {
      return "255.0.0.0";
    } else if (classe === "Classe B") {
      return "255.255.0.0";
    } else if (classe === "Classe C") {
      return "255.255.255.0";
    } else {
      return "N/A";
    }
  }
  
  function calcularEnderecoRede(octetos, mascara) {
    var enderecoRede = [];
    for (var i = 0; i < octetos.length; i++) {
      enderecoRede.push(octetos[i] & mascara.split(".")[i]);
    }
    return enderecoRede.join(".");
  }
  
  function calcularBroadcast(octetos, mascara) {
    var broadcast = [];
    for (var i = 0; i < octetos.length; i++) {
      broadcast.push(octetos[i] | (~mascara.split(".")[i] & 255));
    }
    return broadcast.join(".");
  }